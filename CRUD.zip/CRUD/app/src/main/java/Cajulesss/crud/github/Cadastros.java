package Cajulesss.crud.github;

public class Cadastros {
private String nome_aluno;
private String sobrenome_aluno;
private String telefone;

//Construtor
//public Cadastros(String no_al,String sobreno){
  //System.out.println("Vamos criar um cadastro:");
  //this.nome_aluno = no_al;
  //this.sobrenome_aluno = sobreno;
//}


public String getNome_aluno(){
  return this.nome_aluno;
}

public void setNome_aluno(String aluno_nome){
  this.nome_aluno = aluno_nome;
 }
 
public String getSobrenome_aluno(){
  return this.sobrenome_aluno;
}

public void setSobrenome_aluno(String Aluno_Sobrenome){
  this.sobrenome_aluno = Aluno_Sobrenome;
} 
public void status_nome(){
 System.out.println("Nome fornecido:"+this.nome_aluno +this.sobrenome_aluno);
 }
 
public String getTelefone(){
  return this.telefone;  
}

public void setTelefone(String Verifica_telefone){
  this.telefone = Verifica_telefone;
}

//public void status_telefone(){
//  System.out.println("Testando classe status_telefone");
 }
}
//Problema no construtor

