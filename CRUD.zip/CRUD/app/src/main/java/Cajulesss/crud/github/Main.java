package Cajulesss.crud.github;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.text.ParseException;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//import java.util.regex.*;

public class Main {

  public static void main(String[]args)throws ParseException{
   Date data = new Date();
   SimpleDateFormat data_formatada = new SimpleDateFormat("dd/MM/yyyy");
   String data_formatada_usuario = data_formatada.format(data);
   System.out.println("Data de acesso:"+data_formatada_usuario);
   
   // data_ultimo_acesso;
   Scanner resp = new Scanner(System.in);
   
   System.out.println("Digite sua data de nascimento:");
   
   Date data_Nascimento = data_formatada.parse(resp.next());
 
  
  System.out.println("Data de nascimento fornecida:"+data_Nascimento);
  
  System.out.println("______________________________________________________________");
  System.out.println("\n");
  Cadastros cd = new Cadastros();
  
  System.out.println("Digite seu nome:");
  System.out.println("Fique a vontade para colocar seu nome social! ");
  cd.setNome_aluno(resp.next());
  
  System.out.println("Digite seu sobrenome:");
   cd.setSobrenome_aluno(resp.next());
   cd.status_nome();
   
   System.out.println("\n");
   
   System.out.println("Digite seu telefone: ");
   cd.setTelefone(resp.next());
   cd.status_telefone();
   
   //VALIDAÇÃO TELEFONE
   //String entrada = resp.next();
   //Pattern numero_telefone = Pattern.compile"[(]*\d{2}[)-]\s*)(\d{3,9}[-]*)(\d{4})";
   //Matcher entrada = Pattern.matcher(entrada);
   //System.out.println(numero_telefone);
   
  //int sim = 1, nao = 2;
   System.out.println("Deseja continuar?");
    System.out.println("(1 = sim / 2 = não)");
    
   int repita = resp.nextInt();
   
   int i = 1;
   while(repita==i){
    i++;
   System.out.println("\n");
   System.out.println("Deseja continuar?");
    System.out.println("(1 = sim / 2 = não)");
   
   System.out.println("Data de acesso:"+data_formatada_usuario);
   
   // data_ultimo_acesso;
   
   System.out.println("Digite sua data de nascimento:");
  
  System.out.println("Data de nascimento fornecida:"+data_Nascimento);
  
  System.out.println("______________________________________________________________");
  System.out.println("\n");
  
  System.out.println("Digite seu nome:");
  System.out.println("Fique a vontade para colocar seu nome social! ");
  cd.setNome_aluno(resp.next());
  
  System.out.println("Digite seu sobrenome:");
   cd.setSobrenome_aluno(resp.next());
   cd.status_nome();
   
   System.out.println("\n");
   
   System.out.println("Digite seu telefone: ");
   cd.setTelefone(resp.next());
   //cd.status_telefone();
  }
  
  //VERSÃO 1 do CRUD
  // Tem problema ao adicionar nova data de nascimento
  // Problema na validação de telefone e criação de padrão na data de nascimento,sendo assim válido qualquer data até como 245/08/2034.
  
  // problema na data de último acesso

  //VERSÃO 2- resolver esses problemas e adcionar o contrutor pra facilitar ao inserir dados novos e além da criação do arraylist que não possui na VERSÃO 1.
   
  }
}
